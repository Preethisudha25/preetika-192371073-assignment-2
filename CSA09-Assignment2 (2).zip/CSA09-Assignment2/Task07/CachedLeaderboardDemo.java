import java.util.*;

public class CachedLeaderboardDemo {
    static class Team {
        final String name; final int points;
        Team(String n,int p){name=n;points=p;}
    }
    static class OriginalBoard {
        final List<Team> items=new ArrayList<>();
        void add(Team t){items.add(t);}
        List<Team> ranking(){
            List<Team> copy=new ArrayList<>(items);
            copy.sort(Comparator.comparingInt((Team t)->t.points).reversed().thenComparing(t->t.name));
            return copy;
        }
    }
    static class CachedBoard {
        final List<Team> items=new ArrayList<>();
        List<Team> cache=null;
        void add(Team t){items.add(t);cache=null;}
        List<Team> ranking(){
            if(cache==null){
                cache=new ArrayList<>(items);
                cache.sort(Comparator.comparingInt((Team t)->t.points).reversed().thenComparing(t->t.name));
            }
            return new ArrayList<>(cache);
        }
    }
    public static void main(String[] args) {
        int n=20000, reads=100;
        OriginalBoard original=new OriginalBoard(); CachedBoard cached=new CachedBoard();
        for(int i=0;i<n;i++){Team t=new Team("Team"+i,(i*37)%1000);original.add(t);cached.add(t);}
        long s=System.nanoTime();
        for(int i=0;i<reads;i++) original.ranking();
        long originalTime=System.nanoTime()-s;
        s=System.nanoTime();
        for(int i=0;i<reads;i++) cached.ranking();
        long cachedTime=System.nanoTime()-s;
        System.out.println("n="+n+", ranking reads="+reads);
        System.out.println("Original repeated sort: "+originalTime+" ns");
        System.out.println("Cached ranking: "+cachedTime+" ns");
        System.out.println("Cache invalidation: add() sets cache to null.");
    }
}

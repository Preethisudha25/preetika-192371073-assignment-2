import java.util.*;

public class ListBenchmark {
    static volatile long sink;
    static long time(Runnable r) {
        long s = System.nanoTime(); r.run(); return System.nanoTime() - s;
    }
    static void run(int n) {
        System.out.println("\nSize = " + n);
        ArrayList<Integer> a = new ArrayList<>();
        LinkedList<Integer> l = new LinkedList<>();
        for (int i = 0; i < n; i++) { a.add(i); l.add(i); }

        long t = time(() -> { for (int i = 0; i < n; i++) a.add(i); });
        System.out.println("ArrayList append n: " + t + " ns");
        t = time(() -> { for (int i = 0; i < Math.min(n, 2000); i++) l.addLast(i); });
        System.out.println("LinkedList append up to 2000: " + t + " ns");

        int reps = Math.min(n, 2000);
        t = time(() -> { for (int i = 0; i < reps; i++) a.add(0, -i); });
        System.out.println("ArrayList front insert " + reps + ": " + t + " ns");
        t = time(() -> { for (int i = 0; i < reps; i++) l.addFirst(-i); });
        System.out.println("LinkedList front insert " + reps + ": " + t + " ns");

        int mid = a.size() / 2;
        t = time(() -> { for (int i = 0; i < reps; i++) a.add(a.size()/2, i); });
        System.out.println("ArrayList middle insert " + reps + ": " + t + " ns");
        t = time(() -> { for (int i = 0; i < reps; i++) l.add(l.size()/2, i); });
        System.out.println("LinkedList middle insert " + reps + ": " + t + " ns (includes traversal)");

        t = time(() -> { for (int i = 0; i < 10000; i++) sink += a.get(i % a.size()); });
        System.out.println("ArrayList indexed access 10000: " + t + " ns");
        t = time(() -> { for (int i = 0; i < 10000; i++) sink += l.get(i % l.size()); });
        System.out.println("LinkedList indexed access 10000: " + t + " ns");

        t = time(() -> { long sum=0; for (int v : a) sum += v; sink=sum; });
        System.out.println("ArrayList iteration: " + t + " ns");
        t = time(() -> { long sum=0; for (int v : l) sum += v; sink=sum; });
        System.out.println("LinkedList iteration: " + t + " ns");

        ArrayDeque<Integer> d = new ArrayDeque<>();
        t = time(() -> { for (int i=0;i<n;i++) { d.addFirst(i); d.addLast(i); } });
        System.out.println("ArrayDeque add both ends (2n): " + t + " ns");
        t = time(() -> { while (!d.isEmpty()) d.removeFirst(); });
        System.out.println("ArrayDeque remove front: " + t + " ns");
    }
    public static void main(String[] args) {
        for (int n : new int[]{1000, 10000, 50000}) run(n);
    }
}

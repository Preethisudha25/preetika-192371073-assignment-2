# CSA09 – Programming in Java – Assignment 2
**Name:** ____________________  
**Register number:** ____________________  
**GitHub link:** ____________________

> **Execution note:** Run the Java programs in each task folder and paste your own console screenshots and measured timings into the evidence sections. Timing values are machine-dependent. The included programs are designed to generate the evidence; no fabricated timings are presented as if they came from your computer.

---

## Q1 – Building Text Under Load (6 marks)

### Prediction
`String` is immutable. Each concatenation creates a new string and copies the previous content plus the new field. Repeated `+` in a loop therefore creates many temporary objects and can copy an increasing amount of text. `StringBuilder` maintains a mutable character buffer and appends fields into it, reducing intermediate strings. `StringBuffer` has similar append behaviour but synchronizes its methods, adding overhead when only one thread owns the builder.

For a short ticket, the difference may be negligible because the amount of text is small. For thousands of tickets with many fields, the repeated-concatenation approach is expected to be slower and create more temporary objects.

### Three workloads
1. **Small:** 1 ticket × 6 fields – represents a short booking.
2. **Large:** 10,000 tickets × 50 fields – represents a busy booking service.
3. **Custom:** 2,000 tickets × 200 fields – stresses long tickets with many components.

`Task01/StringBuildBenchmark.java` runs all three workloads, warms up the JVM, repeats each measurement and prints average elapsed time. It also prints an estimated intermediate-string count for the repeated-concatenation approach. This count is an estimate of concatenation results, not an exact JVM allocation count.

### Complexity
Let `n` be the number of fields and `L` the average field length. Repeated concatenation can copy approximately `L(1 + 2 + ... + n)`, giving O(n²) character-copy work for similarly sized fields. A builder appends the total of `n` fields, giving O(n) character-copy work in the usual amortized analysis. Both final results require O(total output length) space. Repeated concatenation may additionally retain temporary strings during construction; builder uses a growable buffer plus the final string.

### Design decision
- **Per-ticket text:** use a local `StringBuilder`. It is not shared between threads, so synchronization is unnecessary.
- **Shared booking log:** use a synchronized logging mechanism or a single-threaded logging service. If choosing only between these classes, a shared `StringBuffer` makes individual append operations synchronized, but it does not make a multi-operation logging transaction atomic. In production, a logging framework or a lock around the complete operation is preferable.

### Alternative: `String.join`, `StringJoiner`, `String.format`
`String.join(delimiter, fields)` or `StringJoiner` can express joining cleanly and avoid repeated loop concatenation. They still need to traverse and copy the field contents into the final result, so expected work is linear in total output length. `String.format` is convenient for fixed layouts but usually has more formatting overhead and is not the best choice for a high-volume simple join.

### Evidence and conclusion
Run `StringBuildBenchmark` and record its printed averages in the table below. Compare the three approaches under identical workloads. The expected trend is that `StringBuilder` and `StringBuffer` scale better than repeated `+`; `StringBuilder` is normally preferred for per-ticket construction because it avoids synchronization overhead.

| Workload | Approach | Your average time (ns) |
|---|---|---:|
| Small | String / StringBuilder / StringBuffer | ______ |
| Large | String / StringBuilder / StringBuffer | ______ |
| Custom | String / StringBuilder / StringBuffer | ______ |

---

## Q2 – When Is ArrayList Appropriate? (4 marks)

### Experimental design
`Task02/ListBenchmark.java` compares `ArrayList` and `LinkedList` at three sizes (1,000; 10,000; 50,000 elements). It measures append, front insertion/removal, middle insertion/removal, indexed access and full iteration. The benchmark uses repeated operations and reports elapsed time. Run it on your system and capture the output.

### Complexity comparison

| Operation | ArrayList | LinkedList | ArrayDeque |
|---|---:|---:|---:|
| Add at end | O(1) amortized | O(1) | O(1) amortized |
| Insert at front | O(n) | O(1) | O(1) |
| Insert in middle | O(n) | O(n) to reach position; O(1) link change | Not supported by index; typically O(n) if rebuilt |
| Remove at front | O(n) | O(1) | O(1) |
| Get k-th | O(1) | O(n) | No indexed access |
| Iterate all | O(n) | O(n) | O(n) |
| Approx. storage per element | One reference slot; spare capacity possible | Node with item + two links | One reference slot in circular array; spare capacity possible |

### Recommendation
`ArrayList` is a reasonable choice when the playlist is read frequently, users jump to arbitrary positions, and appends are common while front/middle edits are relatively rare. It provides constant-time indexed access and cache-friendly iteration. I would reconsider it when front or middle insertion/removal becomes a dominant operation on very large playlists, because shifting elements costs O(n).

### Changed condition: Up Next
For a queue with frequent additions at both ends and removals from the front, `ArrayDeque` is a better fit. It supports efficient operations at both ends and avoids the per-node memory overhead of `LinkedList`. It is not a replacement for the indexed playlist because it has no `get(k)` operation.

### Plain array alternative
A fixed plain array can append in O(1) while capacity remains, but insertion/removal at the front or middle requires shifting up to O(n) references. Indexed access is O(1), iteration is O(n). A dynamically resized array adds occasional O(n) resizing, giving amortized O(1) append.

### Conclusion
Use `ArrayList` for the main playlist when random access and iteration dominate; use `ArrayDeque` for the Up Next queue. Use `LinkedList` only when operations are performed through an already-positioned iterator or node and its extra memory cost is acceptable.

---

## Q3 – Engineer the hashCode–equals Contract (6 marks)

### Three tests and predictions
1. **Apparently successful test:** insert one object only. Predicted size: 1. There is no duplicate to expose a contract error.
2. **Duplicate scan test:** insert two distinct `Student` objects with the same registration number. With the faulty class, their default identity-based hash codes may send them to different buckets, so `equals` may never be called; predicted result is that duplicates can remain. The exact result depends on hash bucket placement and is not guaranteed to fail for every pair.
3. **Mutable-key test:** insert a student, then change a field used by `hashCode`. A later lookup/removal may fail because the object is now in the bucket selected by its old hash. The supplied corrected class uses a final registration number to prevent this mutation.

### How HashSet works
`HashSet` is backed by a hash table. It computes `hashCode()` to choose a bucket, then uses `equals()` to distinguish keys within the relevant bucket. The contract requires equal objects to have equal hash codes. Unequal objects may share a hash code; that is a collision and is handled by `equals`.

### Correct implementation
`Task03/Attendance.java` overrides `hashCode()` using `Objects.hash(regNo)` and keeps `regNo` final. Equality and hashing use the same identity field. Run it before and after enabling the TODO section (commented version is supplied as `Attendance_Before.java`); the corrected program should print `Unique students: 2`.

### Alternative designs
- `TreeSet<Student>` with a comparator on registration number: insertion/search is O(log n), and it naturally stores students in registration-number order. The comparator must return zero exactly when the students should be treated as duplicates.
- `HashMap<String, Student>` keyed by registration number: average O(1) insertion/lookup, with one map entry per unique ID. It stores a key and value reference per entry, so its overhead is comparable to a hash set plus the explicit key/value mapping.

For n unique students, both structures use O(n) space. HashSet has average O(1) add/contains; TreeSet has O(log n) operations.

### Conclusion
Never mutate a field used by `equals` or `hashCode` while an object is stored in a hash-based collection. Use immutable identity fields and implement both methods consistently.

---

## Q4 – Choosing a Map for Pharmacy Inventory (6 marks)

### Expected behaviour

| Map | put/get | Iteration | Natural order |
|---|---:|---:|---|
| HashMap | O(1) average | O(n) | No guaranteed order |
| TreeMap | O(log n) | O(n) | Sorted by key |
| LinkedHashMap | O(1) average | O(n) | Insertion order |

The code-order report is naturally produced by `TreeMap`. The insertion-order report is naturally produced by `LinkedHashMap`. A HashMap requires copying keys/entries and sorting for a code-order report (O(n log n)); it does not preserve insertion order.

### Implementation and experiment
`Task04/InventoryMapBenchmark.java` inserts 1,000, 10,000 and 50,000 medicine records into each map, measures 100,000 lookups, and measures report iteration. It checks whether code-order and insertion-order outputs meet the required ordering. Run it and record the output from your machine.

### Deployment decision
For hundreds of lookups per day, all three are likely to feel responsive at ordinary inventory sizes. Define an acceptable lookup target, for example **under 5 ms for 100,000 in-memory lookups** on the deployment machine. Use the measured output to verify this target rather than assuming it. A practical design can maintain a `HashMap` for fast code lookups and a `TreeMap` or sorted view for the code-order report, but this duplicates index references and increases memory. If one map must serve both reporting requirements, use `LinkedHashMap` for insertion order and create a sorted copy for the code-order report, or use `TreeMap` and separately preserve insertion order. Choose based on which report is more important and measured scale.

### Why not Hashtable?
`Hashtable` is a legacy synchronized collection. Modern code generally uses `HashMap` when external synchronization is unnecessary, or `ConcurrentHashMap` for concurrent access. `Hashtable` also disallows null keys and values and is less flexible.

### Sorted-array alternative
Store entries in an array sorted by medicine code. Binary search lookup is O(log n). Insertion requires finding the position in O(log n), then shifting elements in O(n). Producing the code-order report is O(n) because the array is already sorted. Space is O(n), with compact storage but costly insertion. HashMap offers average O(1) lookup and TreeMap offers O(log n) lookup and ordered iteration without shifting an array.

---

## Q5 – Generic Ranking Component (7 marks)

### Design
A `Comparator<Team>` is preferable to making `Team` implement `Comparable<Team>` when ranking rules may vary by event or when the same generic leaderboard must rank teams, players, colleges and quiz teams. `Comparable` is suitable only when the type has one clear natural ordering. The generic `Leaderboard<T>` accepts `Comparator<? super T>`, allowing a comparator of T or one of its supertypes. A method accepting `List<? extends T>` can read items from a list of T or a subtype without unsafe casts.

### Comparator
Compare points descending, then goal difference descending, then name ascending. Use `comparingInt` and `thenComparing`; avoid subtraction because integer overflow can produce an incorrect comparison. The implementation is in `Task05/LeaderboardDemo.java`.

### Correctness
Each comparison stage is itself a consistent ordering. The next stage is consulted only when the previous stage ties. Lexicographic composition of consistent comparators remains transitive. The final name comparison provides deterministic ordering for different teams with the same points and goal difference. If names can also duplicate, a unique team ID should be added as a final tie-breaker.

Bisons is above Panthers because both have 9 points and goal difference 4, so the final alphabetical comparison places “Bisons” before “Panthers”.

### Alternative approaches
- `Comparable<Team>` places one natural ranking inside Team, but makes reuse with different ranking policies less flexible.
- Three stable sorts can be used in reverse priority order: sort by name ascending, then goal difference descending, then points descending. With stable sorts, each later sort preserves the previous order among ties. This performs three O(n log n) sorts rather than one O(n log n) comparator sort, and is usually more work.
- A single comparator sort is O(n log n) time. `List.sort` may use O(n) temporary storage depending on implementation. The supplied `ranking()` returns a sorted copy, so it also uses O(n) space for the copy.

### Conclusion
A generic `Leaderboard<T>` with an injected comparator is reusable and keeps ranking policy outside the data class.

---

## Q6 – Priority, Order and Fairness in a Queue (8 marks)

### Design
A FIFO `Queue` alone serves strictly by arrival time and cannot ensure that the most severe patient is selected first. A `PriorityQueue` ordered by severity ascending (1 is most critical), then arrival sequence ascending, enforces the required policy. A monotonically increasing arrival counter gives every patient a unique sequence number and preserves FIFO order among equal severities.

`Task06/Triage.java` implements the design. Expected output:
`Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)`

Calling `PriorityQueue.toString()` does not display sorted treatment order. The heap guarantees only that its head is the least element; the remaining internal array is not fully sorted. Repeatedly poll a copy to display priority order without destroying the live queue.

### Complexity and growth
- Add/admit: O(log n)
- Poll next: O(log n)
- Peek: O(1)
- Display all in priority order by polling a copy: O(n log n)
- Space: O(n)

`Task06/TriageBenchmark.java` measures insertion and removal for 1,000, 10,000 and 50,000 patients.

### Starvation and fairness
A severity-5 patient can wait indefinitely if higher-severity patients keep arriving, because strict priority always selects the more severe patient. One possible policy is aging: for every fixed waiting interval, improve a patient's effective priority by one level, up to the critical level. Recompute priorities periodically or use a scheduler that updates queue entries; changing a field in-place while an object is inside a PriorityQueue is unsafe because the heap is not automatically re-ordered. Clinical triage rules must remain primary; aging should only be applied within clinically approved safety constraints.

### Alternative implementations
- **Sorted LinkedList:** find the correct insertion point in O(n), insert O(1) after reaching it; remove first in O(1). Space O(n), with node overhead.
- **Five FIFO queues:** enqueue into the matching severity queue in O(1). To serve, inspect severity queues from 1 to 5 and remove from the first non-empty queue; this is O(1) because there are only five levels. Space O(n) plus five queue objects. It preserves arrival order within each severity.
- **PriorityQueue:** O(log n) add and poll, O(n) space; flexible if priorities are not limited to five fixed values.

### Deployment decision
A city hospital receiving 5,000 patients per day is not a large workload for a PriorityQueue; O(log n) operations are efficient. The queue data structure alone is not sufficient for deployment: triage policy, concurrent admissions, persistence, audit logs, clinical overrides and starvation safeguards must also be addressed. A thread-safe service or synchronized access is required if multiple intake threads modify the same queue.

---

## Q7 – Diagnose, Redesign and Validate (13 marks)

### Selected limitation: repeated sorting for leaderboard display
The original leaderboard can sort its entire list every time `ranking()` is requested. If the display is refreshed frequently while only a few teams change, most sorting work is repeated unnecessarily.

### A. Diagnose the bottleneck
Sorting n entries costs O(n log n) per request. If the leaderboard is requested r times without changes, the total sorting cost is O(r n log n). The expensive operation is repeated comparison and rearrangement even when the data has not changed.

### B. Design objective
Cache the sorted ranking and invalidate the cache only when a team is added or updated. Objective: after the first ranking calculation, repeated ranking requests without modifications should return a copy of the cached result in O(n) time for copying, rather than sorting again in O(n log n).

### C. Revised design
Maintain:
- `items`: original insertion collection.
- `cachedRanking`: sorted snapshot, initially null.
- `add(item)`: append item and set cache to null.
- `ranking()`: if cache is null, copy and sort once; return a defensive copy.

This preserves the original data and ranking correctness. It uses O(n) additional memory for the cached sorted snapshot. If updates are frequent and reads rare, caching may not help; if reads greatly outnumber updates, it reduces repeated work.

### D. Prediction
For one update followed by many ranking requests, the first request should still cost O(n log n), while later requests should avoid sorting and cost O(n) to copy. For a single ranking request after every update, the benefit may be small.

### E. Implementation and validation
`Task07/CachedLeaderboardDemo.java` compares repeated uncached sorting with cached ranking calls using the same data and number of reads. It prints elapsed times. Run it on your machine and capture the output. The benchmark includes copying costs and should be interpreted as an experiment, not a universal performance guarantee.

### F. Final evaluation
The redesign is appropriate when ranking reads are frequent and changes are relatively infrequent. It trades O(n) extra memory for reduced repeated sorting. The original approach is simpler and may be preferable for small lists or when every request follows a data change. The design must invalidate the cache on every mutation; otherwise it could return stale rankings.

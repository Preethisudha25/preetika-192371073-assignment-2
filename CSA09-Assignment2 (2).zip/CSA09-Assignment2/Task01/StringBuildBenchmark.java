import java.util.*;

public class StringBuildBenchmark {
    interface Builder { String build(String[] fields); }

    static String byPlus(String[] fields) {
        String s = "";
        for (String field : fields) s += field;
        return s;
    }
    static String byStringBuilder(String[] fields) {
        StringBuilder b = new StringBuilder();
        for (String field : fields) b.append(field);
        return b.toString();
    }
    static String byStringBuffer(String[] fields) {
        StringBuffer b = new StringBuffer();
        for (String field : fields) b.append(field);
        return b.toString();
    }
    static long measure(Builder builder, String[] fields, int tickets, int repeats) {
        long total = 0;
        for (int r = 0; r < repeats; r++) {
            long start = System.nanoTime();
            long checksum = 0;
            for (int t = 0; t < tickets; t++) checksum += builder.build(fields).length();
            total += System.nanoTime() - start;
            if (checksum == -1) System.out.println(checksum);
        }
        return total / repeats;
    }
    static void run(String name, int tickets, int fieldCount) {
        String[] fields = new String[fieldCount];
        for (int i = 0; i < fieldCount; i++) fields[i] = "field" + i + "|";
        int repeats = tickets == 1 ? 1000 : 5;
        // Warm-up
        for (int i = 0; i < 2; i++) byStringBuilder(fields);
        System.out.println("\n" + name + " (" + tickets + " tickets x " + fieldCount + " fields)");
        System.out.printf("String +        : %d ns%n", measure(StringBuildBenchmark::byPlus, fields, tickets, repeats));
        System.out.printf("StringBuilder    : %d ns%n", measure(StringBuildBenchmark::byStringBuilder, fields, tickets, repeats));
        System.out.printf("StringBuffer     : %d ns%n", measure(StringBuildBenchmark::byStringBuffer, fields, tickets, repeats));
        System.out.println("Estimated concatenation-result strings for +: about " + (long) tickets * fieldCount);
    }
    public static void main(String[] args) {
        run("Small", 1, 6);
        run("Large", 10000, 50);
        run("Custom", 2000, 200);
    }
}

import java.util.*;

public class TriageBenchmark {
    static class P { final int severity; final long arrival;
        P(int s,long a){severity=s;arrival=a;} }
    static void run(int n) {
        PriorityQueue<P> q=new PriorityQueue<>(Comparator.comparingInt((P p)->p.severity).thenComparingLong(p->p.arrival));
        long s=System.nanoTime();
        for(int i=0;i<n;i++) q.add(new P(i%5+1,i));
        long add=System.nanoTime()-s;
        s=System.nanoTime();
        while(!q.isEmpty()) q.poll();
        long remove=System.nanoTime()-s;
        System.out.println("n="+n+" add="+add+" ns, poll-all="+remove+" ns");
    }
    public static void main(String[] args){run(1000);run(10000);run(50000);}
}

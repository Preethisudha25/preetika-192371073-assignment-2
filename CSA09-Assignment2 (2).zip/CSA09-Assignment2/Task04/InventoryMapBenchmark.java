import java.util.*;

public class InventoryMapBenchmark {
    static class Medicine {
        final String code; final String name; int stock;
        Medicine(String code, String name, int stock) { this.code=code; this.name=name; this.stock=stock; }
    }
    static String code(int i) { return String.format("MED%07d", i); }
    static long lookups(Map<String, Medicine> map, int n) {
        long sum=0, start=System.nanoTime();
        for (int i=0;i<100_000;i++) {
            Medicine m=map.get(code(i % n));
            if (m != null) sum += m.stock;
        }
        long elapsed=System.nanoTime()-start;
        if (sum == -1) System.out.println(sum);
        return elapsed;
    }
    static void run(int n) {
        Map<String,Medicine> hash=new HashMap<>();
        Map<String,Medicine> tree=new TreeMap<>();
        Map<String,Medicine> linked=new LinkedHashMap<>();
        for (int i=0;i<n;i++) {
            Medicine m=new Medicine(code(i), "Medicine"+i, i%500);
            hash.put(m.code,m); tree.put(m.code,m); linked.put(m.code,m);
        }
        System.out.println("\nMedicines: "+n);
        System.out.println("100,000 HashMap lookups: "+lookups(hash,n)+" ns");
        System.out.println("100,000 TreeMap lookups: "+lookups(tree,n)+" ns");
        System.out.println("100,000 LinkedHashMap lookups: "+lookups(linked,n)+" ns");
        long s=System.nanoTime(); String firstHash=null; for(String k:hash.keySet()) firstHash=k;
        System.out.println("HashMap iteration: "+(System.nanoTime()-s)+" ns");
        s=System.nanoTime(); String firstTree=null; for(String k:tree.keySet()) firstTree=k;
        System.out.println("TreeMap code-order report: "+(System.nanoTime()-s)+" ns; sorted="+isSorted(tree.keySet()));
        s=System.nanoTime(); String firstLinked=null; for(String k:linked.keySet()) firstLinked=k;
        System.out.println("LinkedHashMap insertion-order report: "+(System.nanoTime()-s)+" ns; first="+firstLinked);
    }
    static boolean isSorted(Collection<String> keys) {
        String prev=null; for(String k:keys) { if(prev!=null && prev.compareTo(k)>0) return false; prev=k; } return true;
    }
    public static void main(String[] args) { for(int n:new int[]{1000,10000,50000}) run(n); }
}

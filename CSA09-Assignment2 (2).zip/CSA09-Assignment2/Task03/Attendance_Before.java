import java.util.*;
class StudentBefore {
    String regNo, name;
    StudentBefore(String regNo, String name) { this.regNo=regNo; this.name=name; }
    @Override public boolean equals(Object o) {
        if (!(o instanceof StudentBefore)) return false;
        return regNo.equals(((StudentBefore)o).regNo);
    }
    // hashCode is intentionally not overridden for the experiment.
}
public class Attendance_Before {
    public static void main(String[] args) {
        Set<StudentBefore> set = new HashSet<>();
        set.add(new StudentBefore("192311001","Arun"));
        set.add(new StudentBefore("192311002","Divya"));
        set.add(new StudentBefore("192311001","Arun"));
        System.out.println("Unique students before fix: " + set.size());
    }
}

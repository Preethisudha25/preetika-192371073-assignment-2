import java.util.*;

class Student {
    private final String regNo;
    private final String name;
    Student(String regNo, String name) { this.regNo = regNo; this.name = name; }
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student)) return false;
        Student other = (Student) o;
        return regNo.equals(other.regNo);
    }
    // TODO 1 completed: equal registration numbers produce equal hash codes.
    @Override public int hashCode() { return Objects.hash(regNo); }
    @Override public String toString() { return regNo + " " + name; }
}
public class Attendance {
    public static void main(String[] args) {
        Set<Student> present = new HashSet<>();
        present.add(new Student("192311001", "Arun"));
        present.add(new Student("192311002", "Divya"));
        present.add(new Student("192311001", "Arun"));
        System.out.println("Unique students: " + present.size());
        System.out.println("Set: " + present);

        // Additional test: same ID, different display name is still the same student.
        Set<Student> second = new HashSet<>();
        second.add(new Student("192311003", "Kavi"));
        second.add(new Student("192311003", "Kavitha"));
        System.out.println("Same-ID test size: " + second.size());
    }
}

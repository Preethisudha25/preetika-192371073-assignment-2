# CSA09 – Programming in Java – Assignment 2

**Student name:** ____________________  
**Register number:** ____________________  
**Java version:** JDK 17 or later (the programs use standard Java APIs)  
**GitHub repository:** `CSA09-<RegisterNumber>-Assignment2`

## Contents
- `Task01/` – String, StringBuilder and StringBuffer experiments
- `Task02/` – ArrayList, LinkedList and ArrayDeque experiments
- `Task03/` – hashCode–equals contract and HashSet tests
- `Task04/` – HashMap, TreeMap and LinkedHashMap comparison
- `Task05/` – Generic leaderboard and comparator
- `Task06/` – Stable emergency triage priority queue
- `Task07/` – Redesign case study based on repeated sorting
- `Assignment_Answers.md` – written answers, predictions, complexity analysis and conclusions

## Compile and run
Open a terminal in the required task folder. For a file containing a public class named `Example`:

```bash
javac Example.java
java Example
```

For the experiment programs, use the same commands with the class name shown in each folder. No external libraries are required.

## Execution evidence
Run each program on your own computer. Save terminal screenshots in the matching task folder (for example, `Task01/output.png`). Benchmark timings depend on CPU, JVM, memory, operating system and background load. The programs print measurements on the computer where they are run; do not copy timings from another machine as your own.

## GitHub submission
1. Create a repository named `CSA09-<RegisterNumber>-Assignment2`.
2. Copy the contents of this folder into the repository.
3. Add your name, register number and Java version above.
4. Commit each task separately, for example:
   - `Add Task01 string construction experiments`
   - `Add Task02 collection comparison`
   - Continue through Task07.
5. Push the commits and paste the repository URL on the assignment cover page and in the submission field.
